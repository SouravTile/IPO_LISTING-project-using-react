import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import './App.css';
import IPOList from './Component/IPOList';
import OYO from './Component/OYO';
import GoAir from './Component/GoAir';
import BAJAJENERGY from './Component/BAJAJENERGY';

function App() {
  return (
    <Router>
      <div className="container">
        <nav>
          <Link to="/" className="button1">Home</Link>
        </nav>
        <Routes>
          <Route path="/" element={<IPOList />} />
          <Route path="/oyo" element={<OYO />} />
          <Route path="/goair" element={<GoAir />} />
          <Route path="/bajaj-energy" element={<BAJAJENERGY />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
