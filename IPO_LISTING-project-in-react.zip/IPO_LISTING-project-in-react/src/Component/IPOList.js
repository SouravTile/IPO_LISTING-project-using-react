import React from 'react';
import { Link } from 'react-router-dom';
import '../App.css';
import oyoLogo from './images/oyo.png';
import bajajLogo from './images/bajaj.png';
import goairLogo from './images/goair.png';

const IPOList = () => {
  return (
    <div className="listhead">
      <h1>IPO List :</h1>
      <div className="ipo-list-wrapper">
        <table className="table">
          <thead>
            <tr className="table-row">
              <th className="table-cell-header">Company / Issue date</th>
              <th className="table-cell-header">Issue size</th>
              <th className="table-cell-header">Price range</th>
              <th className="table-cell-header">Min invest/qty</th>
            </tr>
          </thead>
          <tbody>
            <tr className="table-row" style={{ backgroundColor: 'white' }}>
              <td className="table-cell">
                <img src={goairLogo} alt="goair logo" className="oyo-logo" />
                <Link to="/goair">GO AIR</Link>
                <br />
                4th - 7th Oct 2022
              </td>
              <td className="table-cell">₹3600 Crores</td>
              <td className="table-cell">₹50 - 60</td>
              <td className="table-cell">
                ₹50,000
                <br />
                100 Shares/5 Lots
              </td>
            </tr>
            <tr className="table-row" style={{ backgroundColor: 'white' }}>
              <td className="table-cell">
                <img src={bajajLogo} alt="bajaj logo" className="oyo-logo" />
                <Link to="/bajaj-energy">BAJAJ ENERGY</Link>
                <br />
                4th - 7th Oct 2022
              </td>
              <td className="table-cell">₹3600 Crores</td>
              <td className="table-cell">₹50 - 60</td>
              <td className="table-cell">
                ₹50,000
                <br />
                100 Shares/5 Lots
              </td>
            </tr>
            <tr className="table-row" style={{ backgroundColor: 'white' }}>
              <td className="table-cell">
                <img src={oyoLogo} alt="OYO logo" className="oyo-logo" />
                <Link to="/oyo">OYO</Link>
                <br />
                To be announced
              </td>
              <td className="table-cell">₹3600 Crores</td>
              <td className="table-cell">₹50 - 60</td>
              <td className="table-cell">
                ₹50,000
                <br />
                100 Shares/5 Lots
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default IPOList;
