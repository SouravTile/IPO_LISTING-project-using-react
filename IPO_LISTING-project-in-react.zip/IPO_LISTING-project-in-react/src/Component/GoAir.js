import goairLogo from './images/goair.png'

function GoAir() {

    const handleDownload = () => {
        const htmlContent = document.documentElement.outerHTML;
        const blob = new Blob([htmlContent], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'goair_page_content.html';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    return (
        <div className="details-wrapper">
            <div className="header">
                <div>
                    <h2>IPO details</h2>
                    <h1 className="oyo-header">
                        <img src={goairLogo} alt="GO AIR logo" className="oyo-logo" />
                        GO AIR
                    </h1>
                    <p>GO AIR Private Limited</p>
                </div>
                <button className="download" onClick={handleDownload}>
                    <i className="bi bi-file-earmark-arrow-down-fill"></i>
                </button>
                <button className="button">Apply now</button>
            </div>
            <div>
                <h2>IPO details</h2>
                <div className="ipo-info IPO">
                    <div className="ipo-inforow1">
                        <p>Issue size:</p>
                        <h3>₹2,877 - 3,028 Cr.</h3>
                        <p>Price range:</p>
                        <h3>₹1,026 - 1,080</h3>
                        <p>Minimum amount:</p>
                        <h3>₹50,000</h3>
                        <p>Lot size:</p>
                        <h3>150 shares/lots</h3>
                    </div>
                    <div className="ipo-inforow2">
                        <p>listed on:</p>
                        <h3>15 Dec 22</h3>
                        <p>Minimum quantity:</p>
                        <h3>150 shares</h3>
                        <p>Issue dates:</p>
                        <h3>12 Dec - 15 Dec 22</h3>
                        <p>Listing gains:</p>
                        <h3>₹10(10.0%)</h3>
                    </div>
                </div>
            </div>

            <div className="timeline">
                <h2>IPO timeline</h2>

                <div className="timeline-item">
                    <div className="circle completed" ></div>
                    <div>
                        <h3>Bidding starts:</h3>
                        <li>12 Dec 2023</li>
                    </div>
                </div>
                <div className="timeline-item">
                    <div className="circle completed"></div>
                    <div>
                        <h3>Bidding ends:</h3>
                        <li>5 Dec 2023</li>
                    </div>
                </div>
                <div className="timeline-item">
                    <div className="circle completed"></div>
                    <div>
                        <h3>Allotment finalisation:</h3>
                        <li>18 Dec 2023</li>
                    </div>
                </div>
                <div className="timeline-item">
                    <div className="circle completed"></div>
                    <div>
                        <h3>Refund initiation:</h3>
                        <li>18 Dec 2023</li>
                    </div>
                </div>
                <div className="timeline-item">
                    <div className="circle completed"></div>
                    <div>
                        <h3>Demat transfer:</h3>
                        <li>18 Dec 2023</li>
                    </div>
                </div>
                <div className="timeline-item">
                    <div className="circle completed" ></div>
                    <div>
                        <h3>Listing date:</h3>
                        <li>21 Dec 2023</li>
                    </div>
                </div>
                <div className="timeline-connector"></div>
            </div>
            <div className="about">
                <h2>About the company</h2>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque nisi est, facilisis ac tellus ac, egestas
                    hendrerit magna. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque nisi est, facilisis ac tellus ac, egestas
                    hendrerit magna. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque nisi est, facilisis ac tellus ac, egestas
                    hendrerit magna. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque nisi est, facilisis ac tellus ac, egestas
                    hendrerit magna. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque nisi est, facilisis ac tellus ac, egestas
                    hendrerit magna.
                </p>
            </div>
        </div>
    );
}
export default GoAir; 